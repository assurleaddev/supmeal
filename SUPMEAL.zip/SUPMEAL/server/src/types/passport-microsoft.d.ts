declare module 'passport-microsoft';
